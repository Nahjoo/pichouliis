-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mer. 17 avr. 2019 à 15:01
-- Version du serveur :  5.7.24
-- Version de PHP :  7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `pichouliis`
--

-- --------------------------------------------------------

--
-- Structure de la table `fos_user`
--

DROP TABLE IF EXISTS `fos_user`;
CREATE TABLE IF NOT EXISTS `fos_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username_canonical` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_canonical` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `confirmation_token` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_957A647992FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_957A6479A0D96FBF` (`email_canonical`),
  UNIQUE KEY `UNIQ_957A6479C05FB297` (`confirmation_token`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `fos_user`
--

INSERT INTO `fos_user` (`id`, `username`, `username_canonical`, `email`, `email_canonical`, `enabled`, `salt`, `password`, `last_login`, `confirmation_token`, `password_requested_at`, `roles`) VALUES
(5, 'Pichoulis', 'pichoulis', 'pichoulis@mail.fr', 'pichoulis@mail.fr', 1, NULL, '$2y$13$PItpHzgM9YiLToW8.r8TbutL1dq.j3ZnVeaUxx4K13N9ePpEdnSWa', NULL, NULL, NULL, 'a:1:{i:0;s:10:\"ROLE_ADMIN\";}');

-- --------------------------------------------------------

--
-- Structure de la table `legume`
--

DROP TABLE IF EXISTS `legume`;
CREATE TABLE IF NOT EXISTS `legume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `legume`
--

INSERT INTO `legume` (`id`, `name`) VALUES
(1, 'Courges'),
(2, 'Choux'),
(3, 'Tomates'),
(4, 'Poivrons'),
(5, 'Courgettes'),
(6, 'Carottes'),
(7, 'Artichauts'),
(8, 'Poireaux'),
(9, 'Pommes de terre'),
(10, 'Oignons'),
(11, 'Echalottes'),
(12, 'Ail'),
(13, 'Navet');

-- --------------------------------------------------------

--
-- Structure de la table `legume_planche`
--

DROP TABLE IF EXISTS `legume_planche`;
CREATE TABLE IF NOT EXISTS `legume_planche` (
  `legume_id` int(11) NOT NULL,
  `planche_id` int(11) NOT NULL,
  PRIMARY KEY (`legume_id`,`planche_id`),
  KEY `IDX_3F831F3F25F18E37` (`legume_id`),
  KEY `IDX_3F831F3FDA8652A8` (`planche_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `legume_tache`
--

DROP TABLE IF EXISTS `legume_tache`;
CREATE TABLE IF NOT EXISTS `legume_tache` (
  `legume_id` int(11) NOT NULL,
  `tache_id` int(11) NOT NULL,
  PRIMARY KEY (`legume_id`,`tache_id`),
  KEY `IDX_C41CFF6D25F18E37` (`legume_id`),
  KEY `IDX_C41CFF6DD2235D39` (`tache_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migration_versions`
--

DROP TABLE IF EXISTS `migration_versions`;
CREATE TABLE IF NOT EXISTS `migration_versions` (
  `version` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migration_versions`
--

INSERT INTO `migration_versions` (`version`, `executed_at`) VALUES
('20190415203549', '2019-04-15 20:36:03'),
('20190415204843', '2019-04-15 20:48:48'),
('20190415213134', '2019-04-15 21:31:39'),
('20190416072636', '2019-04-17 13:11:46'),
('20190416083947', '2019-04-17 13:11:47'),
('20190416110652', '2019-04-17 13:11:49'),
('20190416134445', '2019-04-17 13:11:49'),
('20190417131759', '2019-04-17 13:18:09');

-- --------------------------------------------------------

--
-- Structure de la table `planche`
--

DROP TABLE IF EXISTS `planche`;
CREATE TABLE IF NOT EXISTS `planche` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_id` int(11) DEFAULT NULL,
  `subarea_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ABF41FB89F2C3FAB` (`zone_id`),
  KEY `IDX_ABF41FB8F66DE853` (`subarea_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `planche`
--

INSERT INTO `planche` (`id`, `zone_id`, `subarea_id`, `name`) VALUES
(1, 1, 5, 'Planche 1'),
(2, 1, 5, 'Planche 2'),
(3, 1, 5, 'Planche 3'),
(4, 1, 5, 'Planche 4'),
(5, 1, 5, 'Planche 5'),
(6, 1, 5, 'Planche 6'),
(7, 1, 5, 'Planche 7'),
(8, 1, 5, 'Planche 8'),
(9, 1, 5, 'Planche 9'),
(10, 1, 5, 'Planche 10'),
(11, 1, 5, 'Planche 11'),
(12, 1, 5, 'Planche 12'),
(13, 1, 5, 'Planche 13'),
(14, 1, 5, 'Planche 14'),
(15, 1, 5, 'Planche 15'),
(16, 1, 5, 'Planche 16'),
(17, 1, 5, 'Planche 17'),
(18, 1, 5, 'Planche 18'),
(19, 1, 5, 'Planche 19'),
(20, 1, 5, 'Planche 20'),
(21, 1, 5, 'Planche 21'),
(22, 1, 5, 'Planche 22'),
(23, 1, 5, 'Planche 23'),
(24, 1, 5, 'Planche 24'),
(25, 1, 5, 'Planche 25'),
(26, 1, 5, 'Planche 26'),
(27, 1, 5, 'Planche 27'),
(28, 1, 5, 'Planche 28'),
(29, 1, 5, 'Planche 29'),
(30, 1, 5, 'Planche 30'),
(31, 1, 5, 'Planche 31'),
(32, 1, 5, 'Planche 32'),
(33, 1, 5, 'Planche 33'),
(34, 1, 5, 'Planche 34'),
(35, 1, 5, 'Planche 35'),
(36, 1, 5, 'Planche 36'),
(37, 1, 5, 'Planche 37'),
(38, 1, 5, 'Planche 38'),
(39, 1, 5, 'Planche 39'),
(40, 1, 5, 'Planche 40'),
(41, 2, 1, 'Planche 1'),
(42, 2, 1, 'Planche 2'),
(43, 2, 1, 'Planche 3'),
(44, 2, 1, 'Planche 4'),
(45, 2, 1, 'Planche 5'),
(46, 2, 1, 'Planche 6'),
(47, 2, 1, 'Planche 7'),
(48, 2, 2, 'Planche 1'),
(49, 2, 2, 'Planche 2'),
(50, 2, 2, 'Planche 3'),
(51, 2, 2, 'Planche 4'),
(52, 2, 2, 'Planche 5'),
(53, 2, 2, 'Planche 6'),
(54, 2, 2, 'Planche 7'),
(55, 2, 3, 'Planche 1'),
(56, 2, 3, 'Planche 2'),
(57, 2, 3, 'Planche 4'),
(58, 2, 3, 'Planche 5'),
(59, 2, 3, 'Planche 6'),
(60, 2, 3, 'Planche 7'),
(61, 2, 4, 'Planche 1'),
(62, 2, 4, 'Planche 2'),
(63, 2, 4, 'Planche 3'),
(64, 2, 4, 'Planche 4'),
(65, 2, 4, 'Planche 5'),
(66, 2, 4, 'Planche 6'),
(67, 2, 4, 'Planche 7'),
(68, 2, 3, 'Planche 3');

-- --------------------------------------------------------

--
-- Structure de la table `rotation`
--

DROP TABLE IF EXISTS `rotation`;
CREATE TABLE IF NOT EXISTS `rotation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_id` int(11) DEFAULT NULL,
  `subarea_id` int(11) DEFAULT NULL,
  `planche_id` int(11) DEFAULT NULL,
  `legume_id` int(11) DEFAULT NULL,
  `variete_id` int(11) DEFAULT NULL,
  `tache_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `choice` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_297C98F19F2C3FAB` (`zone_id`),
  KEY `IDX_297C98F1F66DE853` (`subarea_id`),
  KEY `IDX_297C98F1DA8652A8` (`planche_id`),
  KEY `IDX_297C98F125F18E37` (`legume_id`),
  KEY `IDX_297C98F1620D5460` (`variete_id`),
  KEY `IDX_297C98F1D2235D39` (`tache_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `rotation`
--

INSERT INTO `rotation` (`id`, `zone_id`, `subarea_id`, `planche_id`, `legume_id`, `variete_id`, `tache_id`, `name`, `date`, `amount`, `time`, `choice`, `comment`) VALUES
(1, 1, 5, 4, 3, 5, 2, 'Rotation', '2019-04-15 22:14:15', 50, '0:00:20:800', 'Botte', 'yes'),
(2, 2, 2, 50, 2, 18, 6, 'Rotation', '2019-04-17 13:18:14', NULL, '0:00:30:042', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `subarea`
--

DROP TABLE IF EXISTS `subarea`;
CREATE TABLE IF NOT EXISTS `subarea` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E214FE39F2C3FAB` (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `subarea`
--

INSERT INTO `subarea` (`id`, `zone_id`, `name`) VALUES
(1, 2, 'Serre 1'),
(2, 2, 'Serre 2'),
(3, 2, 'Serre 3'),
(4, 2, 'Serre 4'),
(5, 1, 'Jardin');

-- --------------------------------------------------------

--
-- Structure de la table `tache`
--

DROP TABLE IF EXISTS `tache`;
CREATE TABLE IF NOT EXISTS `tache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `tache`
--

INSERT INTO `tache` (`id`, `name`) VALUES
(1, 'Préparation sol'),
(2, 'Récolte'),
(3, 'Transplantation'),
(4, 'Semis'),
(5, 'Rempotage'),
(6, 'Taille'),
(7, 'Tuteurage'),
(8, 'Couvert');

-- --------------------------------------------------------

--
-- Structure de la table `tache_planche`
--

DROP TABLE IF EXISTS `tache_planche`;
CREATE TABLE IF NOT EXISTS `tache_planche` (
  `tache_id` int(11) NOT NULL,
  `planche_id` int(11) NOT NULL,
  PRIMARY KEY (`tache_id`,`planche_id`),
  KEY `IDX_61A2210DD2235D39` (`tache_id`),
  KEY `IDX_61A2210DDA8652A8` (`planche_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `user_old`
--

DROP TABLE IF EXISTS `user_old`;
CREATE TABLE IF NOT EXISTS `user_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `variete`
--

DROP TABLE IF EXISTS `variete`;
CREATE TABLE IF NOT EXISTS `variete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `legume_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2CD7CD5825F18E37` (`legume_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `variete`
--

INSERT INTO `variete` (`id`, `name`, `legume_id`) VALUES
(1, 'Bérao', 3),
(2, 'Bérao black', 3),
(3, 'Black cherry', 3),
(4, 'Green jebia', 3),
(5, 'Golden jubile', 3),
(6, 'Caro Rich', 3),
(7, 'Bleue de Hongrie', 1),
(8, 'Butternut', 1),
(9, 'Greenwich', 1),
(10, 'Muscade de provence', 1),
(11, 'Red Kuri', 1),
(12, 'Sucrine du Berry', 1),
(13, 'Vert Kabocha', 1),
(14, 'Spaghetti', 1),
(15, 'Rouge Vif D\'etampes', 1),
(16, 'Brocdi batavia F1', 2),
(17, 'Bruxelles Nautic F1', 2),
(18, 'Chinois Kaboko F1', 2),
(19, 'Fleur Belot F1', 2),
(20, 'Bruxelles Integro F1', 2),
(21, 'Early Niagara', 4),
(22, 'Doux Espagne', 4),
(23, 'Alberello di Sarzana', 5),
(24, 'Genavese de gene', 5),
(25, 'Ortolana di Faenza', 5),
(26, 'Zuboda Mutabile', 5),
(27, 'Blanche de virginie', 5),
(28, 'Gold Rush', 5),
(29, 'Nantaise 2 race Milan', 6),
(30, 'Marché de Paris', 6),
(31, 'Impérial Star', 7),
(32, 'Purple flavor', 7),
(33, 'd\'été', 8),
(34, 'd\'hiver Blauwgroene Herfst', 8),
(35, 'Farinto', 8),
(36, 'Belton F1', 8),
(37, 'Vitaton F1', 8),
(38, 'Lady Christl', 9),
(39, 'Vitabella', 9),
(40, 'Bernadette', 9),
(41, 'Agria', 9),
(42, 'Desirée', 9),
(43, 'Jet sel', 10),
(44, 'Centurion', 10),
(45, 'Sturon', 10),
(46, 'Red baron', 10),
(47, 'Blancs de printemps', 10),
(48, 'Longor', 11),
(49, 'Rose de printemps', 12),
(50, 'Hâtif d\'auvergne', 13);

-- --------------------------------------------------------

--
-- Structure de la table `zone`
--

DROP TABLE IF EXISTS `zone`;
CREATE TABLE IF NOT EXISTS `zone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `zone`
--

INSERT INTO `zone` (`id`, `name`) VALUES
(1, 'Jardin'),
(2, 'Serre'),
(3, 'Pépinière'),
(4, 'Plein champs'),
(5, 'Semis');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `legume_planche`
--
ALTER TABLE `legume_planche`
  ADD CONSTRAINT `FK_3F831F3F25F18E37` FOREIGN KEY (`legume_id`) REFERENCES `legume` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_3F831F3FDA8652A8` FOREIGN KEY (`planche_id`) REFERENCES `planche` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `legume_tache`
--
ALTER TABLE `legume_tache`
  ADD CONSTRAINT `FK_C41CFF6D25F18E37` FOREIGN KEY (`legume_id`) REFERENCES `legume` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_C41CFF6DD2235D39` FOREIGN KEY (`tache_id`) REFERENCES `tache` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `planche`
--
ALTER TABLE `planche`
  ADD CONSTRAINT `FK_ABF41FB89F2C3FAB` FOREIGN KEY (`zone_id`) REFERENCES `zone` (`id`),
  ADD CONSTRAINT `FK_ABF41FB8F66DE853` FOREIGN KEY (`subarea_id`) REFERENCES `subarea` (`id`);

--
-- Contraintes pour la table `rotation`
--
ALTER TABLE `rotation`
  ADD CONSTRAINT `FK_297C98F125F18E37` FOREIGN KEY (`legume_id`) REFERENCES `legume` (`id`),
  ADD CONSTRAINT `FK_297C98F1620D5460` FOREIGN KEY (`variete_id`) REFERENCES `variete` (`id`),
  ADD CONSTRAINT `FK_297C98F19F2C3FAB` FOREIGN KEY (`zone_id`) REFERENCES `zone` (`id`),
  ADD CONSTRAINT `FK_297C98F1D2235D39` FOREIGN KEY (`tache_id`) REFERENCES `tache` (`id`),
  ADD CONSTRAINT `FK_297C98F1DA8652A8` FOREIGN KEY (`planche_id`) REFERENCES `planche` (`id`),
  ADD CONSTRAINT `FK_297C98F1F66DE853` FOREIGN KEY (`subarea_id`) REFERENCES `subarea` (`id`);

--
-- Contraintes pour la table `subarea`
--
ALTER TABLE `subarea`
  ADD CONSTRAINT `FK_E214FE39F2C3FAB` FOREIGN KEY (`zone_id`) REFERENCES `zone` (`id`);

--
-- Contraintes pour la table `tache_planche`
--
ALTER TABLE `tache_planche`
  ADD CONSTRAINT `FK_61A2210DD2235D39` FOREIGN KEY (`tache_id`) REFERENCES `tache` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_61A2210DDA8652A8` FOREIGN KEY (`planche_id`) REFERENCES `planche` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `variete`
--
ALTER TABLE `variete`
  ADD CONSTRAINT `FK_2CD7CD5825F18E37` FOREIGN KEY (`legume_id`) REFERENCES `legume` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
